import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertWasteReportSchema, insertFacilitySchema, insertCollectionSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/facilities", async (_req, res) => {
    try {
      const facilities = await storage.getFacilities();
      res.json(facilities);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch facilities" });
    }
  });

  app.get("/api/facilities/:id", async (req, res) => {
    try {
      const facility = await storage.getFacilityById(req.params.id);
      if (!facility) {
        return res.status(404).json({ error: "Facility not found" });
      }
      res.json(facility);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch facility" });
    }
  });

  app.post("/api/facilities", async (req, res) => {
    try {
      const validatedData = insertFacilitySchema.parse(req.body);
      const facility = await storage.createFacility(validatedData);
      res.status(201).json(facility);
    } catch (error: any) {
      console.error("Facility creation error:", error);
      if (error.name === "ZodError") {
        return res.status(400).json({ error: "Invalid facility data", details: error.errors });
      }
      res.status(400).json({ error: "Invalid facility data" });
    }
  });

  app.get("/api/collections", async (_req, res) => {
    try {
      const collections = await storage.getCollections();
      res.json(collections);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch collections" });
    }
  });

  app.get("/api/collections/:id", async (req, res) => {
    try {
      const collection = await storage.getCollectionById(req.params.id);
      if (!collection) {
        return res.status(404).json({ error: "Collection not found" });
      }
      res.json(collection);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch collection" });
    }
  });

  app.post("/api/collections", async (req, res) => {
    try {
      const validatedData = insertCollectionSchema.parse(req.body);
      const collection = await storage.createCollection(validatedData);
      res.status(201).json(collection);
    } catch (error: any) {
      console.error("Collection creation error:", error);
      if (error.name === "ZodError") {
        return res.status(400).json({ error: "Invalid collection data", details: error.errors });
      }
      res.status(400).json({ error: "Invalid collection data" });
    }
  });

  app.patch("/api/collections/:id/status", async (req, res) => {
    try {
      const { status, eta } = req.body;
      const collection = await storage.updateCollectionStatus(req.params.id, status, eta);
      if (!collection) {
        return res.status(404).json({ error: "Collection not found" });
      }
      res.json(collection);
    } catch (error) {
      res.status(500).json({ error: "Failed to update collection status" });
    }
  });

  app.post("/api/reports", async (req, res) => {
    try {
      const validatedData = insertWasteReportSchema.parse(req.body);
      
      if (validatedData.latitude === 0 || validatedData.longitude === 0) {
        return res.status(400).json({ error: "Valid location coordinates are required" });
      }
      
      const report = await storage.createWasteReport(validatedData);
      res.status(201).json(report);
    } catch (error: any) {
      console.error("Report creation error:", error);
      if (error.name === "ZodError") {
        return res.status(400).json({ error: "Invalid report data", details: error.errors });
      }
      res.status(400).json({ error: "Invalid report data" });
    }
  });

  app.get("/api/reports", async (_req, res) => {
    try {
      const reports = await storage.getWasteReports();
      res.json(reports);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch reports" });
    }
  });

  app.get("/api/reports/:id", async (req, res) => {
    try {
      const report = await storage.getWasteReportById(req.params.id);
      if (!report) {
        return res.status(404).json({ error: "Report not found" });
      }
      res.json(report);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch report" });
    }
  });

  app.get("/api/my-reports", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      if (!userId) {
        const reports = await storage.getWasteReports();
        return res.json(reports.slice(0, 10));
      }
      const reports = await storage.getUserWasteReports(userId);
      res.json(reports);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user reports" });
    }
  });

  app.patch("/api/reports/:id/status", async (req, res) => {
    try {
      const { status } = req.body;
      const resolvedAt = status === "resolved" ? new Date() : undefined;
      const report = await storage.updateWasteReportStatus(req.params.id, status, resolvedAt);
      if (!report) {
        return res.status(404).json({ error: "Report not found" });
      }
      res.json(report);
    } catch (error) {
      res.status(500).json({ error: "Failed to update report status" });
    }
  });

  app.get("/api/user-stats", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      
      if (!userId) {
        const defaultStats = {
          id: "demo",
          userId: "demo",
          reportsSubmitted: 0,
          reportsResolved: 0,
          itemsRecycled: 0,
          co2Saved: 0,
          badges: [],
        };
        return res.json(defaultStats);
      }

      let stats = await storage.getUserStats(userId);
      if (!stats) {
        stats = await storage.createUserStats({
          userId,
          reportsSubmitted: 0,
          reportsResolved: 0,
          itemsRecycled: 0,
          co2Saved: 0,
          badges: [],
        });
      }
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user stats" });
    }
  });

  app.patch("/api/user-stats/:userId", async (req, res) => {
    try {
      const stats = await storage.updateUserStats(req.params.userId, req.body);
      if (!stats) {
        return res.status(404).json({ error: "User stats not found" });
      }
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to update user stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
