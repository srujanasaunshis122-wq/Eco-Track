import {
  type User,
  type InsertUser,
  type WasteReport,
  type InsertWasteReport,
  type Facility,
  type InsertFacility,
  type Collection,
  type InsertCollection,
  type UserStats,
  type InsertUserStats,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  createWasteReport(report: InsertWasteReport): Promise<WasteReport>;
  getWasteReports(): Promise<WasteReport[]>;
  getWasteReportById(id: string): Promise<WasteReport | undefined>;
  getUserWasteReports(userId: string): Promise<WasteReport[]>;
  updateWasteReportStatus(id: string, status: string, resolvedAt?: Date): Promise<WasteReport | undefined>;

  getFacilities(): Promise<Facility[]>;
  getFacilityById(id: string): Promise<Facility | undefined>;
  createFacility(facility: InsertFacility): Promise<Facility>;

  getCollections(): Promise<Collection[]>;
  getCollectionById(id: string): Promise<Collection | undefined>;
  getCollectionsByArea(area: string): Promise<Collection[]>;
  createCollection(collection: InsertCollection): Promise<Collection>;
  updateCollectionStatus(id: string, status: string, eta?: number): Promise<Collection | undefined>;

  getUserStats(userId: string): Promise<UserStats | undefined>;
  createUserStats(stats: InsertUserStats): Promise<UserStats>;
  updateUserStats(userId: string, updates: Partial<UserStats>): Promise<UserStats | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private wasteReports: Map<string, WasteReport>;
  private facilities: Map<string, Facility>;
  private collections: Map<string, Collection>;
  private userStats: Map<string, UserStats>;
  private reportCounter: number;

  constructor() {
    this.users = new Map();
    this.wasteReports = new Map();
    this.facilities = new Map();
    this.collections = new Map();
    this.userStats = new Map();
    this.reportCounter = 1000;
    this.seedData();
  }

  private seedData() {
    const facilities: InsertFacility[] = [
      {
        name: "Green Valley Recycling Center",
        address: "123 Eco Street, Green District",
        latitude: 40.7128,
        longitude: -74.006,
        wasteTypes: ["Recyclable", "Electronics", "Paper"],
        operatingHours: "Mon-Fri: 8:00 AM - 6:00 PM, Sat: 9:00 AM - 4:00 PM",
        phone: "(555) 123-4567",
        isOpenNow: "yes",
      },
      {
        name: "City Hazardous Waste Depot",
        address: "456 Safe Lane, Industrial Zone",
        latitude: 40.7589,
        longitude: -73.9851,
        wasteTypes: ["Hazardous", "Batteries", "Chemicals"],
        operatingHours: "Tue-Sat: 9:00 AM - 5:00 PM",
        phone: "(555) 234-5678",
        isOpenNow: "yes",
      },
      {
        name: "Compost Collection Point",
        address: "789 Garden Road, Park Area",
        latitude: 40.7489,
        longitude: -73.9680,
        wasteTypes: ["Compostable", "Organic"],
        operatingHours: "Daily: 7:00 AM - 7:00 PM",
        phone: "(555) 345-6789",
        isOpenNow: "yes",
      },
      {
        name: "North Side Recycling Hub",
        address: "321 Recycle Blvd, North District",
        latitude: 40.7831,
        longitude: -73.9712,
        wasteTypes: ["Recyclable", "Glass", "Metal", "Plastic"],
        operatingHours: "Mon-Sat: 8:00 AM - 7:00 PM",
        phone: "(555) 456-7890",
        isOpenNow: "yes",
      },
      {
        name: "East End E-Waste Center",
        address: "654 Tech Drive, East Side",
        latitude: 40.7282,
        longitude: -73.9942,
        wasteTypes: ["Electronics", "Batteries"],
        operatingHours: "Wed-Sun: 10:00 AM - 6:00 PM",
        phone: "(555) 567-8901",
        isOpenNow: "no",
      },
      {
        name: "Downtown Waste Management",
        address: "987 Central Ave, Downtown",
        latitude: 40.7614,
        longitude: -73.9776,
        wasteTypes: ["Recyclable", "General", "Bulky Items"],
        operatingHours: "Mon-Fri: 7:00 AM - 8:00 PM, Sat-Sun: 9:00 AM - 5:00 PM",
        phone: "(555) 678-9012",
        isOpenNow: "yes",
      },
    ];

    facilities.forEach((facility) => {
      const id = randomUUID();
      this.facilities.set(id, { ...facility, id });
    });

    const collections: InsertCollection[] = [
      {
        area: "Downtown District",
        scheduledTime: new Date(Date.now() + 2 * 60 * 60 * 1000),
        status: "in-progress",
        vehicleId: "WC-2024-001",
        currentLatitude: 40.7589,
        currentLongitude: -73.9851,
        eta: 25,
      },
      {
        area: "Green Valley Neighborhood",
        scheduledTime: new Date(Date.now() + 4 * 60 * 60 * 1000),
        status: "scheduled",
        vehicleId: "WC-2024-002",
        currentLatitude: null,
        currentLongitude: null,
        eta: null,
      },
      {
        area: "North Side Community",
        scheduledTime: new Date(Date.now() - 1 * 60 * 60 * 1000),
        status: "completed",
        vehicleId: "WC-2024-003",
        currentLatitude: null,
        currentLongitude: null,
        eta: null,
      },
      {
        area: "East End Residences",
        scheduledTime: new Date(Date.now() + 24 * 60 * 60 * 1000),
        status: "scheduled",
        vehicleId: "WC-2024-004",
        currentLatitude: null,
        currentLongitude: null,
        eta: null,
      },
    ];

    collections.forEach((collection) => {
      const id = randomUUID();
      this.collections.set(id, { ...collection, id });
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);

    const stats: UserStats = {
      id: randomUUID(),
      userId: id,
      reportsSubmitted: 0,
      reportsResolved: 0,
      itemsRecycled: 0,
      co2Saved: 0,
      badges: [],
    };
    this.userStats.set(id, stats);

    return user;
  }

  async createWasteReport(insertReport: InsertWasteReport): Promise<WasteReport> {
    const id = randomUUID();
    const reportNumber = `WR-${new Date().getFullYear()}-${String(this.reportCounter++).padStart(6, "0")}`;
    const report: WasteReport = {
      ...insertReport,
      id,
      reportNumber,
      status: "pending",
      createdAt: new Date(),
      resolvedAt: null,
    };
    this.wasteReports.set(id, report);

    if (insertReport.userId) {
      const stats = this.userStats.get(insertReport.userId);
      if (stats) {
        stats.reportsSubmitted += 1;
        stats.itemsRecycled += 1;
        stats.co2Saved += 2.5;

        if (stats.reportsSubmitted === 1) {
          stats.badges.push("First Reporter");
        }
        if (stats.reportsSubmitted === 10) {
          stats.badges.push("Active Citizen");
        }
        if (stats.reportsSubmitted === 50) {
          stats.badges.push("Eco Warrior");
        }
      }
    }

    return report;
  }

  async getWasteReports(): Promise<WasteReport[]> {
    return Array.from(this.wasteReports.values()).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async getWasteReportById(id: string): Promise<WasteReport | undefined> {
    return this.wasteReports.get(id);
  }

  async getUserWasteReports(userId: string): Promise<WasteReport[]> {
    return Array.from(this.wasteReports.values())
      .filter((report) => report.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async updateWasteReportStatus(
    id: string,
    status: string,
    resolvedAt?: Date
  ): Promise<WasteReport | undefined> {
    const report = this.wasteReports.get(id);
    if (!report) return undefined;

    report.status = status;
    if (resolvedAt) {
      report.resolvedAt = resolvedAt;
    }

    if (status === "resolved" && report.userId) {
      const stats = this.userStats.get(report.userId);
      if (stats) {
        stats.reportsResolved += 1;
      }
    }

    return report;
  }

  async getFacilities(): Promise<Facility[]> {
    return Array.from(this.facilities.values());
  }

  async getFacilityById(id: string): Promise<Facility | undefined> {
    return this.facilities.get(id);
  }

  async createFacility(insertFacility: InsertFacility): Promise<Facility> {
    const id = randomUUID();
    const facility: Facility = { ...insertFacility, id };
    this.facilities.set(id, facility);
    return facility;
  }

  async getCollections(): Promise<Collection[]> {
    return Array.from(this.collections.values()).sort(
      (a, b) => a.scheduledTime.getTime() - b.scheduledTime.getTime()
    );
  }

  async getCollectionById(id: string): Promise<Collection | undefined> {
    return this.collections.get(id);
  }

  async getCollectionsByArea(area: string): Promise<Collection[]> {
    return Array.from(this.collections.values())
      .filter((collection) => collection.area.toLowerCase().includes(area.toLowerCase()))
      .sort((a, b) => a.scheduledTime.getTime() - b.scheduledTime.getTime());
  }

  async createCollection(insertCollection: InsertCollection): Promise<Collection> {
    const id = randomUUID();
    const collection: Collection = { ...insertCollection, id };
    this.collections.set(id, collection);
    return collection;
  }

  async updateCollectionStatus(
    id: string,
    status: string,
    eta?: number
  ): Promise<Collection | undefined> {
    const collection = this.collections.get(id);
    if (!collection) return undefined;

    collection.status = status;
    if (eta !== undefined) {
      collection.eta = eta;
    }

    return collection;
  }

  async getUserStats(userId: string): Promise<UserStats | undefined> {
    return this.userStats.get(userId);
  }

  async createUserStats(insertStats: InsertUserStats): Promise<UserStats> {
    const id = randomUUID();
    const stats: UserStats = { ...insertStats, id };
    this.userStats.set(insertStats.userId, stats);
    return stats;
  }

  async updateUserStats(
    userId: string,
    updates: Partial<UserStats>
  ): Promise<UserStats | undefined> {
    const stats = this.userStats.get(userId);
    if (!stats) return undefined;

    Object.assign(stats, updates);
    return stats;
  }
}

export const storage = new MemStorage();
