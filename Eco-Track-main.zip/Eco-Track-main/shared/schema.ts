import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const wasteReports = pgTable("waste_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  category: text("category").notNull(),
  description: text("description"),
  latitude: doublePrecision("latitude").notNull(),
  longitude: doublePrecision("longitude").notNull(),
  locationName: text("location_name"),
  images: text("images").array(),
  status: text("status").notNull().default("pending"),
  reportNumber: text("report_number").notNull().unique(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  resolvedAt: timestamp("resolved_at"),
});

export const facilities = pgTable("facilities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  address: text("address").notNull(),
  latitude: doublePrecision("latitude").notNull(),
  longitude: doublePrecision("longitude").notNull(),
  wasteTypes: text("waste_types").array().notNull(),
  operatingHours: text("operating_hours").notNull(),
  phone: text("phone"),
  isOpenNow: text("is_open_now").notNull().default("yes"),
});

export const collections = pgTable("collections", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  area: text("area").notNull(),
  scheduledTime: timestamp("scheduled_time").notNull(),
  status: text("status").notNull().default("scheduled"),
  vehicleId: text("vehicle_id"),
  currentLatitude: doublePrecision("current_latitude"),
  currentLongitude: doublePrecision("current_longitude"),
  eta: integer("eta"),
});

export const userStats = pgTable("user_stats", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull().unique(),
  reportsSubmitted: integer("reports_submitted").notNull().default(0),
  reportsResolved: integer("reports_resolved").notNull().default(0),
  itemsRecycled: integer("items_recycled").notNull().default(0),
  co2Saved: doublePrecision("co2_saved").notNull().default(0),
  badges: text("badges").array().default(sql`'{}'::text[]`),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertWasteReportSchema = createInsertSchema(wasteReports).omit({ 
  id: true, 
  createdAt: true, 
  resolvedAt: true,
  reportNumber: true,
});
export const insertFacilitySchema = createInsertSchema(facilities).omit({ id: true });
export const insertCollectionSchema = createInsertSchema(collections).omit({ id: true });
export const insertUserStatsSchema = createInsertSchema(userStats).omit({ id: true });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type WasteReport = typeof wasteReports.$inferSelect;
export type InsertWasteReport = z.infer<typeof insertWasteReportSchema>;
export type Facility = typeof facilities.$inferSelect;
export type InsertFacility = z.infer<typeof insertFacilitySchema>;
export type Collection = typeof collections.$inferSelect;
export type InsertCollection = z.infer<typeof insertCollectionSchema>;
export type UserStats = typeof userStats.$inferSelect;
export type InsertUserStats = z.infer<typeof insertUserStatsSchema>;
