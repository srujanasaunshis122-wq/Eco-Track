import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Camera, MapPin, Recycle, Leaf, AlertTriangle, Trash2, CheckCircle, ArrowLeft, ArrowRight } from "lucide-react";
import type { InsertWasteReport } from "@shared/schema";

const reportSchema = z.object({
  category: z.string().min(1, "Please select a waste category"),
  description: z.string().optional(),
  latitude: z.number(),
  longitude: z.number(),
  locationName: z.string().optional(),
  images: z.array(z.string()).optional(),
});

type ReportFormData = z.infer<typeof reportSchema>;

const wasteCategories = [
  { id: "recyclable", name: "Recyclable", icon: Recycle, color: "text-blue-600", bgColor: "bg-blue-50 dark:bg-blue-900" },
  { id: "compostable", name: "Compostable", icon: Leaf, color: "text-green-600", bgColor: "bg-green-50 dark:bg-green-900" },
  { id: "hazardous", name: "Hazardous", icon: AlertTriangle, color: "text-orange-600", bgColor: "bg-orange-50 dark:bg-orange-900" },
  { id: "general", name: "General Waste", icon: Trash2, color: "text-gray-600", bgColor: "bg-gray-50 dark:bg-gray-900" },
];

export default function Report() {
  const [step, setStep] = useState(1);
  const [reportNumber, setReportNumber] = useState<string | null>(null);
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [submittedReport, setSubmittedReport] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  useEffect(() => {
    if (step === 2) {
      getCurrentLocation();
    }
  }, [step]);

  const form = useForm<ReportFormData>({
    resolver: zodResolver(reportSchema),
    defaultValues: {
      category: "",
      description: "",
      latitude: 0,
      longitude: 0,
      locationName: "",
      images: [],
    },
  });

  const submitReportMutation = useMutation({
    mutationFn: async (data: ReportFormData) => {
      const payload: InsertWasteReport = {
        category: data.category,
        description: data.description || "",
        latitude: data.latitude,
        longitude: data.longitude,
        locationName: data.locationName || `${data.latitude.toFixed(4)}, ${data.longitude.toFixed(4)}`,
        images: data.images || [],
        userId: undefined,
        status: "pending",
      };
      return await apiRequest("POST", "/api/reports", payload);
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
      queryClient.invalidateQueries({ queryKey: ["/api/my-reports"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user-stats"] });
      setSubmittedReport(data);
      setReportNumber(data.reportNumber);
      setStep(5);
      toast({
        title: "Report submitted successfully!",
        description: `Your report number is ${data.reportNumber}`,
      });
    },
    onError: (error) => {
      console.error("Submit error:", error);
      toast({
        title: "Error submitting report",
        description: "Please try again later",
        variant: "destructive",
      });
    },
  });

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const maxFiles = 3;
    if (uploadedImages.length >= maxFiles) {
      toast({
        title: "Maximum files reached",
        description: `You can upload up to ${maxFiles} photos`,
        variant: "destructive",
      });
      return;
    }

    Array.from(files).slice(0, maxFiles - uploadedImages.length).forEach((file) => {
      if (!file.type.startsWith("image/")) {
        toast({
          title: "Invalid file type",
          description: "Please upload only image files",
          variant: "destructive",
        });
        return;
      }

      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Maximum file size is 5MB",
          variant: "destructive",
        });
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        setUploadedImages((prev) => [...prev, base64]);
        form.setValue("images", [...uploadedImages, base64]);
        toast({
          title: "Photo uploaded",
          description: `${uploadedImages.length + 1} of ${maxFiles} photos added`,
        });
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    const newImages = uploadedImages.filter((_, i) => i !== index);
    setUploadedImages(newImages);
    form.setValue("images", newImages);
    toast({
      title: "Photo removed",
      description: "Photo has been removed from your report",
    });
  };

  const onSubmit = (data: ReportFormData) => {
    const submitData = { ...data, images: uploadedImages };
    submitReportMutation.mutate(submitData);
  };

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      toast({
        title: "Getting location...",
        description: "Please allow location access",
      });
      navigator.geolocation.getCurrentPosition(
        (position) => {
          form.setValue("latitude", position.coords.latitude);
          form.setValue("longitude", position.coords.longitude);
          form.setValue("locationName", `${position.coords.latitude.toFixed(4)}, ${position.coords.longitude.toFixed(4)}`);
          toast({
            title: "Location captured",
            description: "Your current location has been added to the report",
          });
        },
        (error) => {
          console.error("Geolocation error:", error);
          const mockLat = 40.7128 + (Math.random() - 0.5) * 0.1;
          const mockLng = -74.006 + (Math.random() - 0.5) * 0.1;
          form.setValue("latitude", mockLat);
          form.setValue("longitude", mockLng);
          form.setValue("locationName", `${mockLat.toFixed(4)}, ${mockLng.toFixed(4)}`);
          toast({
            title: "Location set",
            description: "Using approximate location (geolocation unavailable)",
          });
        }
      );
    } else {
      const mockLat = 40.7128 + (Math.random() - 0.5) * 0.1;
      const mockLng = -74.006 + (Math.random() - 0.5) * 0.1;
      form.setValue("latitude", mockLat);
      form.setValue("longitude", mockLng);
      form.setValue("locationName", `${mockLat.toFixed(4)}, ${mockLng.toFixed(4)}`);
      toast({
        title: "Location set",
        description: "Using approximate location (geolocation not supported)",
      });
    }
  };

  const nextStep = () => {
    if (step === 1 && !form.getValues("category")) {
      toast({
        title: "Please complete this step",
        description: "Select a waste category to continue",
        variant: "destructive",
      });
      return;
    }
    
    if (step === 2) {
      const lat = form.getValues("latitude");
      const lng = form.getValues("longitude");
      if (lat === 0 || lng === 0) {
        toast({
          title: "Location required",
          description: "Please capture your location or enter coordinates",
          variant: "destructive",
        });
        return;
      }
    }
    
    setStep(step + 1);
  };

  const progress = (step / 5) * 100;

  if (reportNumber) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardHeader className="text-center">
            <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-12 h-12 text-primary" />
            </div>
            <CardTitle className="text-2xl">Report Submitted!</CardTitle>
            <CardDescription>Your waste report has been successfully submitted</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-accent/30 p-4 rounded-lg text-center">
              <p className="text-sm text-muted-foreground mb-1">Report Number</p>
              <p className="text-2xl font-bold text-primary" data-testid="text-report-number">{reportNumber}</p>
            </div>

            {submittedReport?.images && submittedReport.images.length > 0 && (
              <div className="space-y-2">
                <p className="text-sm font-medium text-center">Submitted Evidence ({submittedReport.images.length} photo{submittedReport.images.length !== 1 ? 's' : ''})</p>
                <div className="grid grid-cols-3 gap-2">
                  {submittedReport.images.map((image: string, index: number) => (
                    <img
                      key={index}
                      src={image}
                      alt={`Submitted evidence ${index + 1}`}
                      className="w-full h-24 object-cover rounded-lg border"
                      data-testid={`success-image-${index}`}
                    />
                  ))}
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 gap-3 pt-2">
              <div className="text-center p-3 bg-muted/50 rounded-lg">
                <p className="text-xs text-muted-foreground mb-1">Category</p>
                <p className="font-medium text-sm capitalize">{submittedReport?.category || form.getValues("category")}</p>
              </div>
              <div className="text-center p-3 bg-muted/50 rounded-lg">
                <p className="text-xs text-muted-foreground mb-1">Status</p>
                <p className="font-medium text-sm capitalize">{submittedReport?.status || "Pending"}</p>
              </div>
            </div>

            <p className="text-sm text-muted-foreground text-center">
              You can track the status of your report in your dashboard
            </p>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => {
                  setReportNumber(null);
                  setSubmittedReport(null);
                  setStep(1);
                  setUploadedImages([]);
                  form.reset();
                }}
                data-testid="button-submit-another"
              >
                Submit Another
              </Button>
              <Button 
                className="flex-1"
                onClick={() => window.location.href = "/dashboard"}
                data-testid="button-view-dashboard"
              >
                View Dashboard
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-2xl mx-auto space-y-8">
        <div className="text-center space-y-4">
          <h1 className="text-4xl lg:text-5xl font-bold">Report Waste</h1>
          <p className="text-lg text-muted-foreground">
            Help keep your community clean by reporting waste issues
          </p>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>Step {step} of 4</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} />
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {step === 1 && (
              <Card data-testid="card-step-category">
                <CardHeader>
                  <CardTitle>Select Waste Category</CardTitle>
                  <CardDescription>Choose the type of waste you're reporting</CardDescription>
                </CardHeader>
                <CardContent>
                  <FormField
                    control={form.control}
                    name="category"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <div className="grid grid-cols-2 gap-4">
                            {wasteCategories.map((category) => (
                              <button
                                key={category.id}
                                type="button"
                                onClick={() => field.onChange(category.id)}
                                className={`p-6 rounded-xl border-2 transition-all ${
                                  field.value === category.id
                                    ? "border-primary bg-primary/5"
                                    : "border-border hover-elevate"
                                }`}
                                data-testid={`button-category-${category.id}`}
                              >
                                <category.icon className={`w-12 h-12 ${category.color} mx-auto mb-3`} />
                                <p className="font-semibold">{category.name}</p>
                              </button>
                            ))}
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>
            )}

            {step === 2 && (
              <Card data-testid="card-step-location">
                <CardHeader>
                  <CardTitle>Location</CardTitle>
                  <CardDescription>Where is the waste located?</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    onClick={getCurrentLocation}
                    data-testid="button-get-location"
                  >
                    <MapPin className="w-4 h-4 mr-2" />
                    Use Current Location
                  </Button>

                  <FormField
                    control={form.control}
                    name="locationName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Location Description (Optional)</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="e.g., Near Central Park entrance" 
                            {...field} 
                            data-testid="input-location-name"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="latitude"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Latitude</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              step="any"
                              placeholder="0.0" 
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                              data-testid="input-latitude"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="longitude"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Longitude</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              step="any"
                              placeholder="0.0" 
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                              data-testid="input-longitude"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {step === 3 && (
              <Card data-testid="card-step-photos">
                <CardHeader>
                  <CardTitle>Add Photos (Optional)</CardTitle>
                  <CardDescription>Photos help us better understand the issue (max 3 photos, 5MB each)</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {uploadedImages.length < 3 && (
                    <div className="border-2 border-dashed border-border rounded-xl p-8 text-center hover-elevate cursor-pointer">
                      <Input
                        type="file"
                        accept="image/*"
                        multiple
                        onChange={handleImageUpload}
                        className="hidden"
                        id="photo-upload"
                        data-testid="input-photo-upload"
                      />
                      <label htmlFor="photo-upload" className="cursor-pointer">
                        <Camera className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                        <p className="text-sm font-medium mb-1">Click to upload photos</p>
                        <p className="text-xs text-muted-foreground">
                          {uploadedImages.length === 0 ? "No photos added yet" : `${uploadedImages.length} of 3 photos added`}
                        </p>
                      </label>
                    </div>
                  )}

                  {uploadedImages.length > 0 && (
                    <div className="grid grid-cols-3 gap-4">
                      {uploadedImages.map((image, index) => (
                        <div key={index} className="relative group" data-testid={`image-preview-${index}`}>
                          <img
                            src={image}
                            alt={`Upload ${index + 1}`}
                            className="w-full h-32 object-cover rounded-lg border"
                          />
                          <Button
                            type="button"
                            variant="destructive"
                            size="icon"
                            className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity h-6 w-6"
                            onClick={() => removeImage(index)}
                            data-testid={`button-remove-image-${index}`}
                          >
                            ×
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}

                  {uploadedImages.length === 0 && (
                    <p className="text-xs text-center text-muted-foreground">
                      You can skip this step and submit your report without photos
                    </p>
                  )}
                </CardContent>
              </Card>
            )}

            {step === 4 && (
              <Card data-testid="card-step-description">
                <CardHeader>
                  <CardTitle>Additional Details (Optional)</CardTitle>
                  <CardDescription>Provide any additional information about the waste</CardDescription>
                </CardHeader>
                <CardContent>
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Textarea
                            placeholder="Describe the waste issue..."
                            className="min-h-[150px]"
                            {...field}
                            data-testid="textarea-description"
                          />
                        </FormControl>
                        <FormDescription>
                          Include details like quantity, condition, or any safety concerns
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>
            )}

            <div className="flex gap-4">
              {step > 1 && step < 5 && (
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setStep(step - 1)}
                  className="flex-1"
                  data-testid="button-previous-step"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Previous
                </Button>
              )}
              {step < 4 && (
                <Button
                  type="button"
                  onClick={nextStep}
                  className="flex-1"
                  data-testid="button-next-step"
                >
                  Next
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              )}
              {step === 4 && (
                <Button
                  type="submit"
                  className="flex-1"
                  disabled={submitReportMutation.isPending}
                  data-testid="button-submit-report"
                >
                  {submitReportMutation.isPending ? "Submitting..." : "Submit Report"}
                </Button>
              )}
            </div>
          </form>
        </Form>
      </div>
    </div>
  );
}
