import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { MapPin, Phone, Clock, Navigation, Search } from "lucide-react";
import type { Facility } from "@shared/schema";

export default function Facilities() {
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();
  
  const { data: facilities, isLoading, error } = useQuery<Facility[]>({
    queryKey: ["/api/facilities"],
  });
  
  if (error) {
    toast({
      title: "Error loading facilities",
      description: "Failed to fetch recycling centers. Please try again.",
      variant: "destructive",
    });
  }
  
  const filteredFacilities = facilities?.filter((facility) =>
    facility.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    facility.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
    facility.wasteTypes.some((type) => type.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-4 md:p-8">
        <div className="max-w-6xl mx-auto space-y-8">
          <Skeleton className="h-12 w-64 mx-auto" />
          <Skeleton className="h-10 w-full max-w-md mx-auto" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Skeleton key={i} className="h-64" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="text-center space-y-4">
          <h1 className="text-4xl lg:text-5xl font-bold">Recycling Facilities</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Find nearby waste management facilities and recycling centers
          </p>
        </div>

        <div className="max-w-md mx-auto">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input 
              placeholder="Search by location, name, or waste type..." 
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              data-testid="input-search-facilities"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredFacilities && filteredFacilities.length > 0 ? (
            filteredFacilities.map((facility) => (
              <Card 
                key={facility.id} 
                className="hover-elevate active-elevate-2"
                data-testid={`card-facility-${facility.id}`}
              >
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <CardTitle className="text-xl">{facility.name}</CardTitle>
                    {facility.isOpenNow === "yes" && (
                      <Badge className="bg-green-500 text-white" data-testid={`badge-open-${facility.id}`}>
                        Open Now
                      </Badge>
                    )}
                  </div>
                  <CardDescription className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 flex-shrink-0 mt-0.5" />
                    <span>{facility.address}</span>
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start gap-2">
                    <Clock className="w-4 h-4 flex-shrink-0 mt-0.5 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">
                      {facility.operatingHours}
                    </span>
                  </div>

                  {facility.phone && (
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-muted-foreground" />
                      <a 
                        href={`tel:${facility.phone}`} 
                        className="text-sm text-primary hover:underline"
                        data-testid={`link-phone-${facility.id}`}
                      >
                        {facility.phone}
                      </a>
                    </div>
                  )}

                  <div className="space-y-2">
                    <p className="text-sm font-medium">Accepted Waste Types:</p>
                    <div className="flex flex-wrap gap-2">
                      {facility.wasteTypes.map((type, index) => (
                        <Badge 
                          key={index} 
                          variant="secondary"
                          data-testid={`badge-waste-type-${facility.id}-${index}`}
                        >
                          {type}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <Button 
                    className="w-full" 
                    variant="outline"
                    onClick={() => {
                      window.open(
                        `https://www.google.com/maps/search/?api=1&query=${facility.latitude},${facility.longitude}`,
                        "_blank"
                      );
                    }}
                    data-testid={`button-directions-${facility.id}`}
                  >
                    <Navigation className="w-4 h-4 mr-2" />
                    Get Directions
                  </Button>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <MapPin className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No facilities found</h3>
              <p className="text-muted-foreground">
                Check back later for updates on nearby recycling centers
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
