import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { Trophy, Recycle, Leaf, Award, TrendingUp, Calendar } from "lucide-react";
import type { UserStats, WasteReport } from "@shared/schema";

export default function Dashboard() {
  const { toast } = useToast();
  
  const { data: stats, isLoading: statsLoading, error: statsError } = useQuery<UserStats>({
    queryKey: ["/api/user-stats"],
  });

  const { data: reports, isLoading: reportsLoading, error: reportsError } = useQuery<WasteReport[]>({
    queryKey: ["/api/my-reports"],
  });
  
  if (statsError) {
    toast({
      title: "Error loading stats",
      description: "Failed to fetch your statistics. Please try again.",
      variant: "destructive",
    });
  }
  
  if (reportsError) {
    toast({
      title: "Error loading reports",
      description: "Failed to fetch your reports. Please try again.",
      variant: "destructive",
    });
  }

  if (statsLoading || reportsLoading) {
    return (
      <div className="min-h-screen bg-background p-4 md:p-8">
        <div className="max-w-6xl mx-auto space-y-8">
          <Skeleton className="h-12 w-64" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-32" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-500";
      case "verified":
      case "resolved":
        return "bg-green-500";
      case "rejected":
        return "bg-red-500";
      default:
        return "bg-gray-500";
    }
  };

  const getStatusLabel = (status: string) => {
    return status.charAt(0).toUpperCase() + status.slice(1);
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="space-y-4">
          <h1 className="text-4xl lg:text-5xl font-bold">My Dashboard</h1>
          <p className="text-lg text-muted-foreground">
            Track your environmental impact and contribution
          </p>
        </div>

        {stats && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card data-testid="card-stat-reports-submitted">
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2 text-muted-foreground mb-1">
                    <Calendar className="w-4 h-4" />
                    <CardDescription>Reports Submitted</CardDescription>
                  </div>
                  <CardTitle className="text-4xl">{stats.reportsSubmitted}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    {stats.reportsResolved} resolved
                  </p>
                  <Progress 
                    value={(stats.reportsResolved / Math.max(stats.reportsSubmitted, 1)) * 100} 
                    className="mt-2"
                  />
                </CardContent>
              </Card>

              <Card data-testid="card-stat-items-recycled">
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2 text-muted-foreground mb-1">
                    <Recycle className="w-4 h-4" />
                    <CardDescription>Items Recycled</CardDescription>
                  </div>
                  <CardTitle className="text-4xl">{stats.itemsRecycled}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-1 text-green-600">
                    <TrendingUp className="w-4 h-4" />
                    <span className="text-sm font-medium">Great work!</span>
                  </div>
                </CardContent>
              </Card>

              <Card data-testid="card-stat-co2-saved">
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2 text-muted-foreground mb-1">
                    <Leaf className="w-4 h-4" />
                    <CardDescription>CO₂ Saved (kg)</CardDescription>
                  </div>
                  <CardTitle className="text-4xl">{stats.co2Saved.toFixed(1)}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Equivalent to {(stats.co2Saved / 21).toFixed(0)} trees planted
                  </p>
                </CardContent>
              </Card>

              <Card data-testid="card-stat-badges">
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2 text-muted-foreground mb-1">
                    <Trophy className="w-4 h-4" />
                    <CardDescription>Badges Earned</CardDescription>
                  </div>
                  <CardTitle className="text-4xl">{stats.badges.length}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Keep contributing to earn more
                  </p>
                </CardContent>
              </Card>
            </div>

            {stats.badges.length > 0 && (
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Award className="w-6 h-6 text-primary" />
                    <CardTitle>Your Achievements</CardTitle>
                  </div>
                  <CardDescription>Badges earned for your environmental contributions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-3">
                    {stats.badges.map((badge, index) => (
                      <Badge 
                        key={index} 
                        variant="secondary" 
                        className="px-4 py-2 text-base"
                        data-testid={`badge-achievement-${index}`}
                      >
                        <Trophy className="w-4 h-4 mr-2" />
                        {badge}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Recent Reports</CardTitle>
            <CardDescription>Your waste reports and their current status</CardDescription>
          </CardHeader>
          <CardContent>
            {reports && reports.length > 0 ? (
              <div className="space-y-4">
                {reports.slice(0, 10).map((report) => (
                  <div 
                    key={report.id}
                    className="p-4 rounded-lg border hover-elevate space-y-3"
                    data-testid={`card-report-${report.id}`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="space-y-1 flex-1">
                        <div className="flex items-center gap-3">
                          <p className="font-semibold">Report #{report.reportNumber}</p>
                          <Badge 
                            className={`${getStatusColor(report.status)} text-white`}
                            data-testid={`badge-report-status-${report.id}`}
                          >
                            {getStatusLabel(report.status)}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground capitalize">
                          {report.category} • {report.locationName || "Location not specified"}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Submitted {new Date(report.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      {report.resolvedAt && (
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground">Resolved</p>
                          <p className="text-sm font-medium text-green-600">
                            {new Date(report.resolvedAt).toLocaleDateString()}
                          </p>
                        </div>
                      )}
                    </div>
                    {report.images && report.images.length > 0 && (
                      <div className="flex gap-2 overflow-x-auto">
                        {report.images.slice(0, 3).map((image: string, idx: number) => (
                          <img
                            key={idx}
                            src={image}
                            alt={`Evidence ${idx + 1}`}
                            className="w-20 h-20 object-cover rounded border flex-shrink-0"
                          />
                        ))}
                        {report.images.length > 3 && (
                          <div className="w-20 h-20 bg-muted rounded border flex items-center justify-center text-xs text-muted-foreground">
                            +{report.images.length - 3} more
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Calendar className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">No reports yet</h3>
                <p className="text-muted-foreground mb-4">
                  Start making an impact by submitting your first waste report
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
