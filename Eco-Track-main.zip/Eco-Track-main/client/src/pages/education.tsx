import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Recycle, Leaf, AlertTriangle, Trash2, ChevronDown, ChevronUp, CheckCircle, XCircle } from "lucide-react";
import recyclableImage from "@assets/generated_images/Recyclable_items_educational_grid_72c12beb.png";
import compostableImage from "@assets/generated_images/Compostable_items_educational_grid_33d1df76.png";
import hazardousImage from "@assets/generated_images/Hazardous_waste_educational_grid_113d4c10.png";

const wasteCategories = [
  {
    id: "recyclable",
    name: "Recyclable",
    icon: Recycle,
    color: "text-blue-600",
    bgColor: "bg-blue-50 dark:bg-blue-950",
    borderColor: "border-blue-200 dark:border-blue-800",
    description: "Materials that can be processed and reused",
    image: recyclableImage,
    acceptedItems: [
      "Plastic bottles and containers",
      "Aluminum and tin cans",
      "Glass bottles and jars",
      "Cardboard and paper",
      "Newspapers and magazines",
      "Clean pizza boxes",
    ],
    rejectedItems: [
      "Plastic bags",
      "Styrofoam",
      "Greasy pizza boxes",
      "Broken glass",
    ],
    tips: "Rinse containers before recycling. Remove caps and labels when possible.",
  },
  {
    id: "compostable",
    name: "Compostable",
    icon: Leaf,
    color: "text-green-600",
    bgColor: "bg-green-50 dark:bg-green-950",
    borderColor: "border-green-200 dark:border-green-800",
    description: "Organic materials that can decompose naturally",
    image: compostableImage,
    acceptedItems: [
      "Fruit and vegetable scraps",
      "Coffee grounds and filters",
      "Tea bags",
      "Eggshells",
      "Yard waste and leaves",
      "Shredded paper",
    ],
    rejectedItems: [
      "Meat and dairy",
      "Oils and fats",
      "Pet waste",
      "Diseased plants",
    ],
    tips: "Keep your compost moist but not soaked. Turn it regularly for faster decomposition.",
  },
  {
    id: "hazardous",
    name: "Hazardous",
    icon: AlertTriangle,
    color: "text-orange-600",
    bgColor: "bg-orange-50 dark:bg-orange-950",
    borderColor: "border-orange-200 dark:border-orange-800",
    description: "Dangerous materials requiring special disposal",
    image: hazardousImage,
    acceptedItems: [
      "Batteries",
      "Light bulbs and CFLs",
      "Paint and solvents",
      "Electronics and e-waste",
      "Cleaning chemicals",
      "Motor oil",
    ],
    rejectedItems: [
      "Regular household trash",
      "Recyclable materials",
      "Food waste",
    ],
    tips: "Never mix hazardous waste. Take to designated collection centers only.",
  },
  {
    id: "general",
    name: "General Waste",
    icon: Trash2,
    color: "text-gray-600",
    bgColor: "bg-gray-50 dark:bg-gray-950",
    borderColor: "border-gray-200 dark:border-gray-800",
    description: "Non-recyclable and non-hazardous waste",
    image: null,
    acceptedItems: [
      "Contaminated paper",
      "Broken ceramics",
      "Mirrors",
      "Disposable diapers",
      "Rubber products",
      "Mixed material packaging",
    ],
    rejectedItems: [
      "Recyclables",
      "Hazardous materials",
      "Organic waste",
    ],
    tips: "Minimize general waste by choosing recyclable and compostable options when possible.",
  },
];

export default function Education() {
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);

  const toggleCategory = (categoryId: string) => {
    setExpandedCategory(expandedCategory === categoryId ? null : categoryId);
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="text-center space-y-4">
          <h1 className="text-4xl lg:text-5xl font-bold">Waste Segregation Guide</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Learn how to properly sort your waste and make a positive environmental impact
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {wasteCategories.map((category) => (
            <Card 
              key={category.id} 
              className={`${category.borderColor} border-2`}
              data-testid={`card-category-${category.id}`}
            >
              <CardHeader className={category.bgColor}>
                <div className="flex items-center gap-3">
                  <category.icon className={`w-10 h-10 ${category.color}`} />
                  <div>
                    <CardTitle className="text-xl">{category.name}</CardTitle>
                  </div>
                </div>
                <CardDescription className="mt-2">
                  {category.description}
                </CardDescription>
              </CardHeader>
            </Card>
          ))}
        </div>

        <div className="space-y-6">
          {wasteCategories.map((category) => (
            <Card 
              key={category.id}
              className={`${category.borderColor} border-2`}
              data-testid={`card-detail-${category.id}`}
            >
              <CardHeader 
                className={`${category.bgColor} cursor-pointer hover-elevate`}
                onClick={() => toggleCategory(category.id)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <category.icon className={`w-12 h-12 ${category.color}`} />
                    <div>
                      <CardTitle className="text-2xl">{category.name}</CardTitle>
                      <CardDescription className="mt-1">{category.description}</CardDescription>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" data-testid={`button-toggle-${category.id}`}>
                    {expandedCategory === category.id ? (
                      <ChevronUp className="w-6 h-6" />
                    ) : (
                      <ChevronDown className="w-6 h-6" />
                    )}
                  </Button>
                </div>
              </CardHeader>
              
              {expandedCategory === category.id && (
                <CardContent className="pt-6 space-y-6">
                  {category.image && (
                    <div className="rounded-xl overflow-hidden bg-white">
                      <img 
                        src={category.image} 
                        alt={`${category.name} examples`}
                        className="w-full h-auto"
                      />
                    </div>
                  )}

                  <Tabs defaultValue="accepted" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="accepted" data-testid={`tab-${category.id}-accepted`}>Accepted Items</TabsTrigger>
                      <TabsTrigger value="rejected" data-testid={`tab-${category.id}-rejected`}>Not Accepted</TabsTrigger>
                    </TabsList>
                    <TabsContent value="accepted" className="space-y-3 mt-4">
                      {category.acceptedItems.map((item, index) => (
                        <div 
                          key={index} 
                          className="flex items-center gap-3 p-3 bg-card rounded-lg"
                          data-testid={`item-${category.id}-accepted-${index}`}
                        >
                          <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                          <span>{item}</span>
                        </div>
                      ))}
                    </TabsContent>
                    <TabsContent value="rejected" className="space-y-3 mt-4">
                      {category.rejectedItems.map((item, index) => (
                        <div 
                          key={index} 
                          className="flex items-center gap-3 p-3 bg-card rounded-lg"
                          data-testid={`item-${category.id}-rejected-${index}`}
                        >
                          <XCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
                          <span>{item}</span>
                        </div>
                      ))}
                    </TabsContent>
                  </Tabs>

                  <div className="bg-accent/30 p-4 rounded-lg border border-accent">
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <span className="text-2xl">💡</span>
                      Pro Tip
                    </h4>
                    <p className="text-sm text-muted-foreground">{category.tips}</p>
                  </div>
                </CardContent>
              )}
            </Card>
          ))}
        </div>

        <Card className="bg-gradient-to-r from-primary/10 to-accent/10">
          <CardHeader>
            <CardTitle className="text-2xl text-center">Remember: When in Doubt</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-lg text-muted-foreground">
              If you're unsure about how to dispose of an item, it's better to throw it in general waste than to contaminate recyclable materials.
            </p>
            <p className="text-muted-foreground">
              Contact your local waste management authority for specific guidelines in your area.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
