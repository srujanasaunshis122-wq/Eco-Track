import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Camera, Truck, GraduationCap, LayoutDashboard, Recycle, Leaf, Users } from "lucide-react";
import heroImage from "@assets/generated_images/Hero_waste_sorting_lifestyle_7c566ca9.png";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <div className="relative h-[500px] bg-gradient-to-br from-primary/20 to-accent/30 overflow-hidden">
        <img 
          src={heroImage} 
          alt="Person properly sorting waste" 
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/30 to-transparent" />
        
        <div className="relative h-full flex items-center justify-center px-4">
          <div className="max-w-4xl text-center space-y-6">
            <h1 className="text-4xl lg:text-5xl font-bold text-white drop-shadow-lg">
              Make Every Action Count for a Cleaner Tomorrow
            </h1>
            <p className="text-lg lg:text-xl text-white/90 drop-shadow-md max-w-2xl mx-auto">
              Report waste, find facilities, track collections, and learn proper segregation
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4">
              <Link href="/report">
                <Button 
                  size="lg" 
                  className="backdrop-blur-md bg-primary/90 hover:bg-primary text-primary-foreground w-full sm:w-auto"
                  data-testid="button-report-waste-hero"
                >
                  <Camera className="w-5 h-5 mr-2" />
                  Report Waste
                </Button>
              </Link>
              <Link href="/facilities">
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="backdrop-blur-md bg-background/10 border-white/30 text-white hover:bg-background/20 w-full sm:w-auto"
                  data-testid="button-find-facility-hero"
                >
                  <MapPin className="w-5 h-5 mr-2" />
                  Find Facility
                </Button>
              </Link>
              <Link href="/track">
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="backdrop-blur-md bg-background/10 border-white/30 text-white hover:bg-background/20 w-full sm:w-auto"
                  data-testid="button-track-collection-hero"
                >
                  <Truck className="w-5 h-5 mr-2" />
                  Track Collection
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-16 space-y-20">
        <section>
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">Your Impact in Numbers</h2>
            <p className="text-muted-foreground text-lg">Join thousands making a difference</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card data-testid="card-stat-reports">
              <CardHeader className="pb-3">
                <CardDescription>Total Reports</CardDescription>
                <CardTitle className="text-4xl">12,847</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">+234 this week</p>
              </CardContent>
            </Card>
            <Card data-testid="card-stat-recycled">
              <CardHeader className="pb-3">
                <CardDescription>Items Recycled</CardDescription>
                <CardTitle className="text-4xl">45.2K</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">+1.2K this week</p>
              </CardContent>
            </Card>
            <Card data-testid="card-stat-co2">
              <CardHeader className="pb-3">
                <CardDescription>CO₂ Saved (kg)</CardDescription>
                <CardTitle className="text-4xl">8,943</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">+156 this week</p>
              </CardContent>
            </Card>
            <Card data-testid="card-stat-users">
              <CardHeader className="pb-3">
                <CardDescription>Active Users</CardDescription>
                <CardTitle className="text-4xl">3,421</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">+89 this week</p>
              </CardContent>
            </Card>
          </div>
        </section>

        <section>
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">How It Works</h2>
            <p className="text-muted-foreground text-lg">Three simple steps to start making a difference</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center space-y-4" data-testid="card-how-it-works-report">
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                <Camera className="w-10 h-10 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">1. Report Issues</h3>
              <p className="text-muted-foreground">
                Snap a photo of waste problems in your area and submit a geo-tagged report
              </p>
            </div>
            <div className="text-center space-y-4" data-testid="card-how-it-works-learn">
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                <GraduationCap className="w-10 h-10 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">2. Learn Segregation</h3>
              <p className="text-muted-foreground">
                Discover proper waste segregation techniques with our interactive educational guides
              </p>
            </div>
            <div className="text-center space-y-4" data-testid="card-how-it-works-track">
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                <Truck className="w-10 h-10 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">3. Track Collections</h3>
              <p className="text-muted-foreground">
                Stay informed about waste collection schedules and real-time truck locations
              </p>
            </div>
          </div>
        </section>

        <section>
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">Quick Actions</h2>
            <p className="text-muted-foreground text-lg">Everything you need in one place</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Link href="/report">
              <Card className="hover-elevate active-elevate-2 cursor-pointer h-full" data-testid="card-quick-action-report">
                <CardHeader>
                  <Camera className="w-12 h-12 text-primary mb-4" />
                  <CardTitle>Report Waste</CardTitle>
                  <CardDescription>Submit geo-tagged waste reports</CardDescription>
                </CardHeader>
              </Card>
            </Link>
            <Link href="/facilities">
              <Card className="hover-elevate active-elevate-2 cursor-pointer h-full" data-testid="card-quick-action-facilities">
                <CardHeader>
                  <MapPin className="w-12 h-12 text-primary mb-4" />
                  <CardTitle>Find Facilities</CardTitle>
                  <CardDescription>Locate nearby recycling centers</CardDescription>
                </CardHeader>
              </Card>
            </Link>
            <Link href="/education">
              <Card className="hover-elevate active-elevate-2 cursor-pointer h-full" data-testid="card-quick-action-education">
                <CardHeader>
                  <GraduationCap className="w-12 h-12 text-primary mb-4" />
                  <CardTitle>Learn Segregation</CardTitle>
                  <CardDescription>Interactive waste education</CardDescription>
                </CardHeader>
              </Card>
            </Link>
            <Link href="/dashboard">
              <Card className="hover-elevate active-elevate-2 cursor-pointer h-full" data-testid="card-quick-action-dashboard">
                <CardHeader>
                  <LayoutDashboard className="w-12 h-12 text-primary mb-4" />
                  <CardTitle>My Dashboard</CardTitle>
                  <CardDescription>Track your environmental impact</CardDescription>
                </CardHeader>
              </Card>
            </Link>
          </div>
        </section>

        <section className="bg-gradient-to-r from-primary/10 via-accent/10 to-primary/10 rounded-3xl p-12">
          <div className="text-center space-y-6">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Recycle className="w-10 h-10 text-primary" />
              <Leaf className="w-10 h-10 text-primary" />
              <Users className="w-10 h-10 text-primary" />
            </div>
            <h2 className="text-3xl lg:text-4xl font-bold">Join the Green Movement</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Every action counts. Start your journey towards a cleaner, more sustainable future today.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Link href="/report">
                <Button size="lg" data-testid="button-start-reporting">
                  <Camera className="w-5 h-5 mr-2" />
                  Start Reporting
                </Button>
              </Link>
              <Link href="/education">
                <Button size="lg" variant="outline" data-testid="button-learn-more">
                  <GraduationCap className="w-5 h-5 mr-2" />
                  Learn More
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
