import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Truck, Clock, MapPin, Calendar } from "lucide-react";
import type { Collection } from "@shared/schema";

export default function Track() {
  const { toast } = useToast();
  
  const { data: collections, isLoading, error } = useQuery<Collection[]>({
    queryKey: ["/api/collections"],
  });
  
  if (error) {
    toast({
      title: "Error loading collections",
      description: "Failed to fetch collection schedules. Please try again.",
      variant: "destructive",
    });
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-4 md:p-8">
        <div className="max-w-4xl mx-auto space-y-8">
          <Skeleton className="h-12 w-64 mx-auto" />
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-48" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "scheduled":
        return "bg-blue-500";
      case "in-progress":
        return "bg-yellow-500";
      case "completed":
        return "bg-green-500";
      default:
        return "bg-gray-500";
    }
  };

  const getStatusLabel = (status: string) => {
    return status.split("-").map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(" ");
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center space-y-4">
          <h1 className="text-4xl lg:text-5xl font-bold">Track Collections</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Stay updated on waste collection schedules in your area
          </p>
        </div>

        <div className="space-y-4">
          {collections && collections.length > 0 ? (
            collections.map((collection) => (
              <Card 
                key={collection.id}
                className="hover-elevate"
                data-testid={`card-collection-${collection.id}`}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center gap-3">
                        <Truck className="w-6 h-6 text-primary" />
                        <CardTitle className="text-2xl">{collection.area}</CardTitle>
                      </div>
                      <CardDescription className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        {new Date(collection.scheduledTime).toLocaleDateString(undefined, {
                          weekday: "long",
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })}
                      </CardDescription>
                    </div>
                    <Badge 
                      className={`${getStatusColor(collection.status)} text-white`}
                      data-testid={`badge-status-${collection.id}`}
                    >
                      {getStatusLabel(collection.status)}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Clock className="w-4 h-4" />
                        <span className="text-sm">
                          Scheduled:{" "}
                          {new Date(collection.scheduledTime).toLocaleTimeString(undefined, {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </span>
                      </div>
                      {collection.vehicleId && (
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Truck className="w-4 h-4" />
                          <span className="text-sm">Vehicle ID: {collection.vehicleId}</span>
                        </div>
                      )}
                    </div>

                    {collection.eta && (
                      <div className="bg-primary/10 rounded-lg p-4 text-center">
                        <p className="text-sm text-muted-foreground mb-1">Estimated Time of Arrival</p>
                        <p className="text-3xl font-bold text-primary" data-testid={`text-eta-${collection.id}`}>
                          {collection.eta} min
                        </p>
                      </div>
                    )}
                  </div>

                  {collection.currentLatitude && collection.currentLongitude && (
                    <div className="bg-accent/30 p-4 rounded-lg">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <MapPin className="w-4 h-4" />
                        <span>
                          Current Location: {collection.currentLatitude.toFixed(4)}, {collection.currentLongitude.toFixed(4)}
                        </span>
                      </div>
                    </div>
                  )}

                  {collection.status === "in-progress" && (
                    <div className="bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
                      <p className="text-sm text-yellow-900 dark:text-yellow-100">
                        🚛 Collection vehicle is on the way to your area
                      </p>
                    </div>
                  )}

                  {collection.status === "completed" && (
                    <div className="bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg p-4">
                      <p className="text-sm text-green-900 dark:text-green-100">
                        ✓ Collection completed successfully
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <Truck className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">No collections scheduled</h3>
                <p className="text-muted-foreground">
                  Check back later for upcoming waste collection schedules
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
