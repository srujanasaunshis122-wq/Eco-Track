import { Link, useLocation } from "wouter";
import { Home, GraduationCap, MapPin, Camera, LayoutDashboard } from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { path: "/", label: "Home", icon: Home, testId: "nav-home" },
  { path: "/education", label: "Learn", icon: GraduationCap, testId: "nav-education" },
  { path: "/report", label: "Report", icon: Camera, testId: "nav-report" },
  { path: "/facilities", label: "Facilities", icon: MapPin, testId: "nav-facilities" },
  { path: "/dashboard", label: "Dashboard", icon: LayoutDashboard, testId: "nav-dashboard" },
];

export default function BottomNav() {
  const [location] = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border md:hidden z-50">
      <div className="flex items-center justify-around h-16">
        {navItems.map((item) => {
          const isActive = location === item.path;
          return (
            <Link key={item.path} href={item.path}>
              <button
                className={cn(
                  "flex flex-col items-center justify-center gap-1 px-3 py-2 rounded-lg transition-colors",
                  isActive
                    ? "text-primary"
                    : "text-muted-foreground hover:text-foreground"
                )}
                data-testid={item.testId}
              >
                <item.icon className="w-5 h-5" />
                <span className="text-xs font-medium">{item.label}</span>
              </button>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
